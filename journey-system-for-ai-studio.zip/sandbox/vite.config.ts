import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import path from "path";
import { fileURLToPath } from "url";
import { defineConfig } from "vite";

/**
 * SANDBOX CONFIG — for Google AI Studio (and any other environment with no
 * Firebase credentials). This is NOT how the real app runs.
 *
 * The real app (`npm run dev` in the normal repo) is an Express server
 * (server.ts) that mounts Vite as middleware, talks to Firebase Auth and
 * Firestore, and proxies Mindbody. None of that can work in a sandbox: there
 * are no credentials, no Firestore project and no Mindbody token.
 *
 * So this config replaces every path to Firebase with an in-memory stand-in
 * and serves plain Vite. Nothing here reaches the network.
 *
 * It is the union of the three configs in harness/ (vite.config.ts,
 * vite.history.config.ts, vite.learning.config.ts), so a single dev server
 * can serve every preview page at once.
 */

// Derived from import.meta.url rather than __dirname: this file is ESM, and a
// newer Vite config loader does not provide __dirname at all.
const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "..");
const stub = (f: string) => path.resolve(root, "harness", f);

export default defineConfig({
  root,
  base: "./",
  plugins: [react(), tailwindcss()],

  // server/gemini.ts holds the real key and never ships to the browser. Any
  // client file that merely *reads* the name gets an empty string.
  define: { "process.env.GEMINI_API_KEY": '""' },

  resolve: {
    // Order matters: the most specific patterns first.
    alias: [
      // src/firebase.ts is the single module that initialises the SDK. Every
      // import of it — from anywhere in the tree — lands on the stub instead,
      // so initializeApp() is never called and no listener is ever opened.
      { find: /^(\.\.\/)+firebase$/, replacement: stub("firebase-stub.ts") },
      { find: /^\.\/firebase$/, replacement: stub("firebase-stub.ts") },
      { find: path.resolve(root, "src/firebase.ts"), replacement: stub("firebase-stub.ts") },

      // Components that import the Firestore SDK directly (the History tab and
      // the Learning tab both do) get an in-memory fake instead of the real one.
      { find: /^firebase\/firestore$/, replacement: stub("firestore-stub.ts") },

      // The heavy admin panels each open their own Firestore queries. In the
      // sandbox they render as labelled placeholders.
      {
        find: /^\.\/(AdminMetricsDashboard|AdminStudioManager|AdminUserDirectory|AdminBugReports|AdminHubAnnouncements|InsightsDashboardView|AdminLimboQueue|AdminSystemClients|machines\/AdminMachinesTab|mindbody\/MindbodyDashboard)$/,
        replacement: stub("admin-stubs.tsx"),
      },

      // The active-studio context normally comes from a signed-in session.
      { find: /^(\.\.\/)+ActiveStudioContext$/, replacement: stub("active-studio-stub.tsx") },

      // src/features/demo-mode is not on master — it lives on the unmerged
      // `demo-mode-foundation` branch — but the studio picker preview imports
      // one constant from it.
      { find: /^(\.\.\/)+src\/features\/demo-mode$/, replacement: stub("demo-mode-stub.ts") },

      { find: "@", replacement: root },
      { find: "react", replacement: path.resolve(root, "node_modules/react") },
      { find: "react-dom", replacement: path.resolve(root, "node_modules/react-dom") },
    ],
  },

  server: {
    host: "0.0.0.0",
    port: Number(process.env.PORT) || 3000,
    // A hosted sandbox proxies the dev server under a generated hostname.
    // Without this, Vite answers "Blocked request. This host is not allowed"
    // and the preview pane stays blank — which looks exactly like an app crash.
    allowedHosts: true,
    hmr: process.env.DISABLE_HMR === "true" ? false : true,
  },

  build: {
    outDir: path.resolve(here, "dist"),
    emptyOutDir: true,
    rollupOptions: {
      input: {
        launcher: path.resolve(root, "index.html"),
        screens: path.resolve(root, "harness/index.html"),
        history: path.resolve(root, "harness/history.html"),
        learning: path.resolve(root, "harness/learning.html"),
      },
    },
  },

  logLevel: "warn",
});
