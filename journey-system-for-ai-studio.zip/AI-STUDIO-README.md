# Read this first

This is the **Journey System** — the coaching app used by **Max Strength Fitness**
studios. Trainers record workouts, machine settings and notes on iPads on the gym
floor; studio leaders run the studio from the same app. It replaces a Claris
FileMaker system and syncs people, bookings and contracts from **Mindbody**.

This copy has been **prepared for a sandbox**. It is not the deployed app, and it
is not a plain checkout of the repository either. Read the two sections below
before doing anything, because both change what advice is useful here.

---

## Run it

```bash
npm install
npm run dev
```

That serves a launcher page at `/` with a link to every screen. No credentials, no
sign-in, no network calls — every screen renders immediately.

If a preview pane shows nothing, check the dev server actually started rather than
assuming an app crash; `npm run dev` here is plain Vite, not the real server.

---

## What is real and what is faked

**Real:** every screen, component, stylesheet, design token, layout rule, piece of
copy and interaction in `src/`. What you see rendered is the product's actual UI
code, not a mockup of it.

**Faked:** everything underneath.

| Normally | In this sandbox |
| --- | --- |
| Firebase Auth (Google sign-in) | `harness/firebase-stub.ts` — nothing to sign into |
| Firestore (live `onSnapshot` streams) | `harness/firestore-stub.ts` — in-memory, answers from fixtures |
| Mindbody sync via an Express proxy | absent; no `/api/*` routes exist |
| Heavy admin panels | `harness/admin-stubs.tsx` — labelled placeholders |
| Data | hand-written fixtures in `harness/*.tsx` |

The swap happens entirely in `sandbox/vite.config.ts`, through resolve aliases.
**No application source was modified to make this run.** That is deliberate — it
means any change you suggest applies to the real codebase unaltered.

### What this makes worth critiquing

Layout, spacing, visual hierarchy, colour and contrast, typography, touch-target
sizes, information density, wording, empty states, the order things appear in, and
whether a screen's job is obvious within a second of looking at it.

### What it does not

Loading and error behaviour, realistic data volumes, anything driven by a query,
performance, and anything that depends on a real session. The fixtures are small
and tidy; real studios are neither. Please don't recommend changes premised on the
fake data being representative.

---

## The shape of the codebase

| What | Where |
| --- | --- |
| **Architecture, screen map, data dictionary, roadmap** | `docs/ARCHITECTURE.md` — **read this before proposing anything** |
| House rules and known traps | `CLAUDE.md` |
| How the business works (packages, renewals, roles) | `docs/business/` |
| Feature code | `src/features/<name>/` — most have their own `README.md` |
| Screens | `src/components/`, plus `src/AppContent.tsx` |
| Types | `src/types.ts`, `src/types/` |
| Design tokens | `src/index.css`, `equipment.tokens.css`, `admin.tokens.css` |

There is **no router**. `src/AppContent.tsx` switches on a `currentView` string.

The server (`server.ts`, `server/`), Cloud Functions (`functions/`), Firestore
rules (`firestore.rules`) and scripts (`scripts/`) are all included so you can read
them, but none of them run here.

---

## Constraints that are not up for negotiation

These come from how the studios actually work. A suggestion that breaks one of them
can't be used, however good it looks:

- **iPad-first**, portrait and landscape. Nothing tappable under **40px**. Hover is
  never the only way to find something. Client names are never truncated.
- **Sentences, not scores.** Every claim a screen makes names a minimum sample, and
  below it the screen says "not enough data yet". A confident wrong number is worse
  than a missing one.
- **Nothing contacts clients or trainers.** No email, SMS or push. In-app only.
  Don't propose notifications, reminder emails or outreach of any kind.
- **Use the design tokens**, never raw hex. The red kaizen mark is reserved for rep
  quality and means nothing else.
- **Mindbody owns people, bookings and contracts**; Journey owns coaching data.
- Don't propose changes to the Mindbody integration, the Cloud Functions or the
  Firestore structure.

The app is also used by trainers mid-session with a client in front of them, on a
tablet, standing up. Speed of reading beats density of information every time.

---

## Where you can help most

Roughly in order of usefulness:

1. **Look at each screen and say what is confusing.** Fresh eyes on a UI its author
   has stared at for months is the single most valuable thing here.
2. **Visual consistency.** Screens were built over many rounds and have drifted —
   spacing, corner radii, type scale, button weights. Point at specific
   inconsistencies between specific screens.
3. **The day board and the briefing screen.** These two get used most, under the
   most time pressure. They deserve the hardest look.
4. **Accessibility.** Contrast, target sizes, focus states — for trainers on a
   bright gym floor and for clients in their 70s and 80s reading over a shoulder.
5. **Copy.** Labels, empty states, and anything that reads like developer English
   rather than studio English.

When you propose a change, please name the **file and the component**, and keep it
to something that could ship on its own. Large refactors aren't useful here.

---

## Sandbox quirks — not bugs

- **Google Fonts may not load** depending on the environment's network. The layout
  is unaffected; only the typeface falls back.
- **The admin dashboard shows placeholder panels.** Those panels each open their
  own Firestore queries and are stubbed out by design.
- **Numbers are fixtures.** Session counts, dates and streaks are invented.
- `src/features/demo-mode` is stubbed: that feature lives on an unmerged branch and
  is not part of this snapshot.
- `index.app.html` is the real application's entry point. It is kept for reference
  and **will not start here** — it needs Firebase credentials. `index.html` is the
  sandbox launcher.

## What was changed to make this run

So nothing is mistaken for the real project's setup:

- `sandbox/vite.config.ts` — new; the alias layer described above.
- `index.html` — replaced with the launcher; the real one is `index.app.html`.
- `package.json` — trimmed to the front-end dependencies only, with `dev`, `build`
  and `preview` pointing at the sandbox config. The untouched original is kept
  beside it as `package.real.json`. The server, Cloud Functions, Firebase Admin and
  build-tooling packages were removed because nothing in the browser imports them
  and they make installing slow and failure-prone.
- `firebase-applet-config.json` — a dummy file. The real one is gitignored, and
  `src/firebase.ts` imports it statically, so without *some* file present the
  bundle fails to resolve and the page is blank. The values are never used.
- `harness/` — the author's existing local preview harness, normally excluded from
  git. This is what makes the screens renderable.

Nothing under `src/`, `components/`, `lib/`, `server/` or `functions/` was touched.
