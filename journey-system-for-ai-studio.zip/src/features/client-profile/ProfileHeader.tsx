/**
 * PROFILE HEADER — identity, four headline facts, one loud action.
 *
 * Row 1  ‹ avatar  NAME                                   [▶ START SESSION]
 *        ▪▪▪ studio · client since · flags
 * Row 2  Top trainer │ Last session │ Next session │ Sessions completed · package
 *
 * Decisions (Sep 5 2026 round):
 *  - Top trainer is READ from the persisted tally (useTopTrainer), not
 *    counted from whatever page of history happens to be loaded.
 *  - "Sessions completed" lost its "/ 46 total" tail. The package sits
 *    beside it instead, in Mindbody blue when Mindbody supplied it.
 *  - Next session shows the weekday and the time — "see you Tuesday at
 *    two" is the sentence this tile exists to support.
 *  - Profile Details moved into the tab row; the header keeps exactly one
 *    button, so the eye has nowhere to go but Start Session.
 */
import { useState, type ReactNode } from "react";
import { ChevronLeft, Clock, History, Maximize, Play, Trash2, UserCheck, AlertTriangle, User } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { cn, parseSessionDate } from "../../lib/utils";
import { formatStudioTime, toDate, zonedYMD } from "../../lib/studio-time";
import { clientSinceLabel } from "../../lib/client-since";
import type { Client, ScheduleEntry, WorkoutSession } from "../../types";
import type { PackageSummary } from "./client-package";
import { remainingLabel } from "./client-package";
import type { TopTrainerState } from "./useTopTrainer";
import { tallyRows } from "../../lib/client-rollups";
import type { Trainer } from "../../types";
import { BrandTiles } from "./BrandTiles";
import { bookedLabel, nextSessionHeadline } from "./next-session-tile";

export interface ActiveSessionLike {
  id?: string;
  trainerInitials?: string;
  startTime?: { toMillis?: () => number } | null;
}

/**
 * The Kaizen Roster toggle, passed in rather than wired here.
 *
 * Absent when there is no signed-in trainer to own a roster. The header stays
 * dumb: ClientProfileView owns the mutation, this owns the pixel.
 */
export interface KaizenToggleState {
  isOn: boolean;
  busy?: boolean;
  onToggle: () => void;
}

export interface ProfileHeaderProps {
  client: Client;
  studioName?: string | null;
  sessions: WorkoutSession[];
  scheduledSessions: ScheduleEntry[];
  completedCount: number;
  topTrainer: TopTrainerState;
  /** Everyone on the studio's list, to name the trainers in the tally. */
  trainers?: Trainer[];
  pkg: PackageSummary;
  activeInProgressSession?: ActiveSessionLike | null;
  isCheckingActiveSession?: boolean;
  onBack: () => void;
  onStartSession: () => void;
  onTakeOverSession: () => void;
  onViewCurrentSession: () => void;
  onDiscardSession: () => void;
  kaizen?: KaizenToggleState;
  /**
   * The renewal line (Renewals round, Sep 2026), from the nightly snapshot.
   * When present, the package tile shows it and opens the Renewal card.
   */
  renewal?: RenewalTileState;
}

/** What the package tile says about the renewal, and where a tap goes. */
export interface RenewalTileState {
  /** "9 left · auto-renews Nov 14" — see features/renewals/sentences.ts. */
  text: string;
  tone: "ok" | "warn" | "alert" | "neutral";
  /** Something to talk about now: a conversation due, a charge coming, an ended package. */
  attention: boolean;
  onOpen: () => void;
}

const RENEWAL_TONE: Record<RenewalTileState["tone"], string> = {
  ok: "text-emerald-700 dark:text-emerald-400",
  warn: "text-amber-700 dark:text-amber-400",
  alert: "text-rose-700 dark:text-rose-400",
  neutral: "text-muted-foreground",
};

const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const WEEKDAYS_LONG = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function relativeDays(ms: number): string | null {
  if (!ms) return null;
  const days = Math.round((Date.now() - ms) / 86_400_000);
  if (days <= 0) return "today";
  if (days === 1) return "yesterday";
  if (days < 14) return `${days} days ago`;
  if (days < 60) return `${Math.round(days / 7)} wk ago`;
  return `${Math.round(days / 30)} mo ago`;
}

function daysUntil(d: Date): string | null {
  const start = new Date();
  start.setHours(0, 0, 0, 0);
  const target = new Date(d);
  target.setHours(0, 0, 0, 0);
  const days = Math.round((target.getTime() - start.getTime()) / 86_400_000);
  if (days === 0) return "today";
  if (days === 1) return "tomorrow";
  if (days > 1) return `in ${days} days`;
  return null;
}

/*
 * `clientSince` used to live here as a four-step fallback ending on
 * client.createdAt -- the day the JOURNEY document was made. On a roster
 * imported from Mindbody that last step fires for almost everyone, so the
 * card confidently reported a member of eleven years as joining last month.
 *
 * The rule now lives in lib/client-since.ts, consults the contract and
 * membership dates the commercial sync already writes, and returns its own
 * LABEL -- so a Journey-only date renders as "In Journey since" and cannot
 * pass itself off as a start date at the business.
 */

/* ------------------------------------------------------------------ */

function Stat({
  label,
  icon,
  children,
  sub,
  meter,
  className,
  onClick,
  ariaLabel,
}: {
  label: string;
  icon?: ReactNode;
  children: ReactNode;
  sub?: ReactNode;
  /**
   * Optional fuel gauge drawn on the tile's bottom edge. Absolute, so a
   * ratio becomes readable at a glance without costing the header a single
   * pixel of height — which the Journey grid below spends on machines.
   */
  meter?: { value: number; max: number; label?: string };
  className?: string;
  /** Makes the whole tile a button (≥ 40px tall, as every tappable thing is). */
  onClick?: () => void;
  ariaLabel?: string;
}) {
  const pct =
    meter && meter.max > 0
      ? Math.max(0, Math.min(100, (meter.value / meter.max) * 100))
      : null;
  const Tag = onClick ? "button" : "div";
  return (
    <Tag
      {...(onClick ? { type: "button" as const, onClick, "aria-label": ariaLabel } : {})}
      className={cn(
        "relative min-w-0 bg-white dark:bg-slate-950 px-3 xl:px-2.5 py-2 flex flex-col justify-center gap-0.5",
        pct !== null && "pb-2.5",
        onClick && "text-left min-h-10 hover:bg-slate-50 dark:hover:bg-slate-900 transition-colors",
        className,
      )}
    >
      <span className="text-[10px] font-bold uppercase tracking-[0.14em] text-muted-foreground leading-none">{label}</span>
      <span className="flex items-center gap-2 min-w-0 text-[15px] font-bold leading-tight text-slate-900 dark:text-slate-50">
        {icon && <span className="shrink-0 text-slate-400 dark:text-slate-500 [&>svg]:w-4 [&>svg]:h-4">{icon}</span>}
        <span className="min-w-0 flex items-center gap-2 [&>.truncate]:min-w-0">{children}</span>
      </span>
      {sub && <span className="text-[11px] font-medium leading-none text-slate-500 dark:text-slate-400 min-w-0 flex items-center [&>*]:min-w-0 [&>span:not(.inline-flex)]:truncate">{sub}</span>}
      {pct !== null && (
        <span
          className="absolute inset-x-0 bottom-0 h-1 bg-slate-200/80 dark:bg-slate-800 overflow-hidden"
          role="img"
          aria-label={meter!.label ?? `${meter!.value} of ${meter!.max}`}
        >
          <span
            className="block h-full bg-[#F06C22] transition-[width] duration-500"
            style={{ width: `${pct}%` }}
          />
        </span>
      )}
    </Tag>
  );
}

/* ------------------------------------------------------------------ */

export function ProfileHeader({
  client,
  studioName,
  sessions,
  scheduledSessions,
  completedCount,
  topTrainer,
  trainers = [],
  pkg,
  activeInProgressSession,
  isCheckingActiveSession = false,
  onBack,
  onStartSession,
  onTakeOverSession,
  onViewCurrentSession,
  onDiscardSession,
  kaizen,
  renewal,
}: ProfileHeaderProps) {
  const [showTrainers, setShowTrainers] = useState(false);
  const trainerRows = tallyRows(client.trainerTally, trainers);
  /* ---- last session ---- */
  const last = sessions.find((s) => s.status === "Completed") ?? sessions[0];
  const lastMs = last?.date ? parseSessionDate(last.date) : 0;
  const lastLabel = lastMs ? new Date(lastMs).toLocaleDateString([], { month: "short", day: "numeric", year: "numeric" }) : null;

  /* ---- next session ---- */
  const next = scheduledSessions[0];
  const nextDate = next ? toDate(next.startTime) : null;
  const nextTime = nextDate ? formatStudioTime(nextDate, undefined, "") : "";
  /**
   * "Tuesday 12:30 PM". The month was noise — a next session is days away,
   * never months, and "see you Tuesday at half twelve" is the sentence this
   * tile exists to support. Inside two days the weekday gives way to the
   * word a trainer would actually say.
   */
  // The weekday is read on the STUDIO's clock, like the time printed beside
  // it. `getDay()` reads the viewer's, so a late-evening session opened from
  // a browser a few hours off Eastern showed the wrong weekday next to the
  // right time — exactly the hazard lib/studio-time exists to prevent.
  const nextYMD = nextDate ? zonedYMD(nextDate) : null;
  const nextWeekday =
    nextYMD !== null
      ? WEEKDAYS_LONG[new Date(Date.UTC(nextYMD.year, nextYMD.month - 1, nextYMD.day)).getUTCDay()]
      : null;
  const nextDay = nextDate
    ? daysUntil(nextDate) === "today"
      ? "Today"
      : daysUntil(nextDate) === "tomorrow"
        ? "Tomorrow"
        : nextWeekday
    : null;
  const nextLabel = nextSessionHeadline(nextDay, nextTime);

  /* ---- package ---- */
  const remaining = remainingLabel(pkg);
  const since = clientSinceLabel(client);
  const hasFlags = !!(client.notes || (client.clinicalFlags && client.clinicalFlags.length > 0));
  const initials = `${(client.firstName || "").charAt(0)}${(client.lastName || "").charAt(0)}`.toUpperCase();

  return (
    <header
      className={cn(
        "bg-white dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800/60 pb-2.5 mb-3 pt-1",
        // Portrait (a 13" iPad is 1024px — Tailwind's lg): identity + action on
        // row one, the four facts on row two. Landscape (1366px — xl): one
        // band — identity, facts, action — which hands the Journey grid ~90px
        // more height, the difference between 19 and 21 machines on screen.
        // The identity block gives up its sub-line details until 2xl so the
        // four tiles keep ~180px each.
        "grid gap-x-3 xl:gap-x-4 gap-y-3 items-center",
        "grid-cols-[minmax(0,1fr)_auto] [grid-template-areas:'id_cta'_'strip_strip']",
        "xl:grid-cols-[auto_minmax(0,1fr)_auto] xl:[grid-template-areas:'id_strip_cta']",
      )}
    >
      {/* ---------- identity ---------- */}
      <div className="flex items-center gap-2 sm:gap-3 min-w-0 [grid-area:id]">
        <button
          type="button"
          onClick={onBack}
          aria-label="Back to clients"
          className="shrink-0 h-10 w-10 rounded-full grid place-items-center text-slate-400 hover:text-slate-900 hover:bg-slate-100 dark:text-slate-500 dark:hover:text-white dark:hover:bg-slate-800 transition-colors"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>

        <Avatar size="xl" className="ring-2 ring-slate-200 dark:ring-slate-800 bg-slate-100 dark:bg-slate-800 shrink-0 xl:size-12 2xl:size-14">
          {client.photoUrl && <AvatarImage src={client.photoUrl} alt={`${client.firstName} ${client.lastName}`} />}
          <AvatarFallback className="bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-lg">
            {initials || <User className="w-7 h-7" />}
          </AvatarFallback>
        </Avatar>

        <div className="min-w-0 flex-1 xl:max-w-[240px] 2xl:max-w-[320px]">
          <h1 className="text-2xl md:text-[26px] xl:text-[28px] font-black tracking-tight leading-none text-foreground truncate">
            {client.firstName} {client.lastName}
          </h1>
          <div className="mt-1.5 flex items-center gap-2.5 min-w-0">
            <BrandTiles size={6} gap={2} />
            <span className="text-[10px] font-bold uppercase tracking-[0.14em] text-muted-foreground truncate">
              <span>{studioName}</span>
              {since && (
                <span className="xl:hidden 2xl:inline">
                  {studioName ? "  ·  " : ""}
                  {since.label} {since.value}
                </span>
              )}
              {(client.experienceLevel || client.trainingPedigree) && (
                <span className="xl:hidden 2xl:inline">  ·  {client.experienceLevel || client.trainingPedigree}</span>
              )}
            </span>
            {hasFlags && (
              <span className="hidden sm:inline-flex xl:hidden 2xl:inline-flex items-center gap-1.5 rounded px-2 py-0.5 border border-amber-500/30 bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400 shrink-0">
                <AlertTriangle className="w-3 h-3" />
                <span className="text-[10px] font-bold uppercase tracking-widest">Clinical notes</span>
              </span>
            )}
          </div>
        </div>
      </div>

      {/* ---------- the action. Hero orange appears nowhere else in the header. ---------- */}
      <div className="[grid-area:cta] justify-self-end flex items-center gap-2">
        {/*
          Kaizen Roster toggle. Deliberately quiet and deliberately BLUE: the
          red kaizen mark means "this rep needs work" in the session grid, and
          if the two ever share a colour a glance can no longer tell "I am
          tracking you" from "you are doing it wrong". It also stays visually
          subordinate to Start Session, which is the one loud thing here.
        */}
        {kaizen && (
          <button
            type="button"
            onClick={kaizen.onToggle}
            disabled={kaizen.busy}
            aria-pressed={kaizen.isOn}
            title={kaizen.isOn ? "On your Kaizen Roster — tap to remove" : "Add to your Kaizen Roster"}
            className={cn(
              "shrink-0 inline-flex items-center gap-1.5 h-12 px-3 rounded-2xl border text-[11px] font-bold uppercase tracking-widest transition-colors",
              kaizen.busy && "opacity-50",
              kaizen.isOn
                ? "border-transparent bg-[#0a548b]/10 text-[#034a84] dark:bg-[#4a9fd8]/15 dark:text-[#7cc0ee]"
                : "border-slate-200 dark:border-slate-800 text-muted-foreground hover:text-[#034a84] dark:hover:text-[#7cc0ee]",
            )}
          >
            <svg
              width="16"
              height="16"
              viewBox="0 0 16 16"
              fill="none"
              stroke="currentColor"
              strokeWidth={2}
              strokeLinecap="round"
              strokeLinejoin="round"
              aria-hidden="true"
            >
              <polyline points="2,10 6,6 10,10" opacity={0.55} />
              <polyline points="6,13 10,9 14,13" />
            </svg>
            <span className="hidden sm:inline">{kaizen.isOn ? "Tracking" : "Track"}</span>
          </button>
        )}
        {activeInProgressSession ? (
          <DropdownMenu>
            <DropdownMenuTrigger className="inline-flex items-center gap-2 h-12 px-4 sm:px-5 rounded-2xl bg-amber-500 hover:bg-amber-600 text-white font-display italic uppercase tracking-wider text-sm sm:text-base shadow-[0_10px_30px_-12px_rgba(245,158,11,.8)] transition-colors">
              <Clock className="w-4 h-4 animate-pulse" />
              <span className="hidden sm:inline">In progress</span>
              <span className="text-white/80 text-xs not-italic font-sans font-bold">({activeInProgressSession.trainerInitials})</span>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-64 rounded-2xl p-2 bg-card border-slate-200 dark:border-slate-800">
              <div className="px-3 py-2 mb-2 border-b border-slate-200 dark:border-slate-800">
                <p className="text-[11px] font-medium uppercase text-amber-500 tracking-widest">Active session detected</p>
                <p className="text-[11px] font-bold text-slate-800 dark:text-slate-200 mt-1">
                  Started by {activeInProgressSession.trainerInitials} at{" "}
                  {new Date(activeInProgressSession.startTime?.toMillis?.() || 0).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </p>
              </div>
              <DropdownMenuItem onClick={onTakeOverSession} className="rounded-xl hover:bg-amber-50 dark:hover:bg-amber-500/20 cursor-pointer flex items-center gap-2 p-3 text-amber-700 dark:text-amber-500">
                <Play className="w-4 h-4" />
                <span className="font-bold uppercase text-xs">Take over session</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={onViewCurrentSession} className="rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer flex items-center gap-2 p-3 text-slate-700 dark:text-slate-300">
                <Maximize className="w-4 h-4" />
                <span className="font-bold uppercase text-xs">View current session</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={onDiscardSession} className="rounded-xl hover:bg-red-50 dark:hover:bg-red-500/20 cursor-pointer flex items-center gap-2 p-3 text-red-600 dark:text-red-500">
                <Trash2 className="w-4 h-4" />
                <span className="font-bold uppercase text-xs">Discard session</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        ) : (
          <button
            type="button"
            onClick={onStartSession}
            disabled={isCheckingActiveSession}
            className={cn(
              "group relative shrink-0 inline-flex items-center gap-3 h-12 xl:h-[52px] pl-1.5 pr-3 sm:pr-5 rounded-2xl text-white",
              "bg-[linear-gradient(135deg,#ef5302_0%,#f36d21_100%)] ring-1 ring-white/25 ring-inset",
              "shadow-[0_14px_34px_-14px_rgba(239,83,2,.85)] hover:shadow-[0_18px_40px_-14px_rgba(239,83,2,.95)] hover:brightness-[1.04]",
              "active:scale-[0.98] transition-all disabled:opacity-60 disabled:cursor-wait",
              "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[#0a548b]",
            )}
          >
            <span className="grid place-items-center w-9 h-9 xl:w-10 xl:h-10 rounded-xl bg-white/20 group-hover:bg-white/25 transition-colors">
              <Play className="w-4 h-4 xl:w-[18px] xl:h-[18px] fill-current translate-x-px" />
            </span>
            <span className="hidden sm:flex flex-col items-start leading-none">
              <span className="font-display italic uppercase tracking-wider text-base xl:text-lg">
                {isCheckingActiveSession ? "Checking…" : "Start session"}
              </span>
              {!isCheckingActiveSession && nextDate && daysUntil(nextDate) === "today" && (
                <span className="text-[10px] font-bold uppercase tracking-widest text-white/85 mt-1">Booked today{nextTime ? ` · ${nextTime}` : ""}</span>
              )}
            </span>
          </button>
        )}
      </div>

      {/* ---------- the four facts, hairline-divided ---------- */}
      <div className="[grid-area:strip] min-w-0 grid grid-cols-2 md:grid-cols-4 gap-px bg-slate-200 dark:bg-slate-800 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800">
        {/* Tap for everyone who has trained this client and how often
            (tracker round, Sep 2026 — "a feature we tried to get working"). */}
        <Stat
          label="Top trainer"
          icon={<UserCheck />}
          onClick={trainerRows.length > 0 ? () => setShowTrainers((v) => !v) : undefined}
          ariaLabel={trainerRows.length > 0 ? "Show every trainer who has trained this client" : undefined}
          sub={
            topTrainer.top
              ? topTrainer.source === "tally"
                ? `${topTrainer.top.sessions} of ${topTrainer.top.total} sessions${trainerRows.length > 1 ? ` · ${trainerRows.length} trainers` : ""}`
                : topTrainer.backfilling
                  ? "Counting full history…"
                  : "From recent sessions"
              : undefined
          }
        >
          {topTrainer.top?.name ? <span className="truncate">{topTrainer.top.name}</span> : <span className="text-muted-foreground font-medium">Not yet</span>}
        </Stat>

        <Stat label="Last session" icon={<History />} sub={lastMs ? relativeDays(lastMs) ?? undefined : undefined}>
          {lastLabel ?? <span className="text-muted-foreground font-medium">No sessions yet</span>}
        </Stat>

        {/* "Tomorrow 4:00 PM" read "Tomorro…" on a portrait iPad: the tile is
            ~180px, and the icon and the "2 booked" chip shared its one line.
            Now the headline has the line to itself and may wrap at the dot,
            the chip sits under it with the date, and there is no icon (the
            label already says what it is). */}
        <Stat
          label="Next session"
          sub={
            nextDate ? (
              <span className="inline-flex flex-wrap items-center gap-x-2 gap-y-1">
                <span className="text-muted-foreground whitespace-nowrap">
                  {daysUntil(nextDate) && nextDay !== "Today" && nextDay !== "Tomorrow"
                    ? daysUntil(nextDate)
                    : `${MONTHS[nextDate.getMonth()]} ${nextDate.getDate()}`}
                </span>
                <span className="shrink-0 text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 tracking-wide whitespace-nowrap">
                  {bookedLabel(scheduledSessions.length)}
                </span>
              </span>
            ) : undefined
          }
        >
          {nextLabel ? (
            <span className="whitespace-normal break-words">{nextLabel}</span>
          ) : (
            <span className="text-muted-foreground font-medium italic">Not scheduled</span>
          )}
        </Stat>

        {/* Marker 6: the package used to be "46" shouting next to "of 96 in
            package" whispering, so the ratio never registered. Now the two
            numbers are one fraction at comparable weight, and the tile's
            bottom edge carries a gauge — how much of the package is spent
            is legible without reading a digit. */}
        {/* "52 of 96 — I don't know where the 96 comes from; it needs to be
            removed" (audit, Sep 13). The count stands alone; what is left on
            the CONTRACT is the sub-line, from the renewal snapshot. */}
        <Stat
          label="Completed sessions"
          onClick={renewal?.onOpen}
          ariaLabel={renewal ? `Renewal: ${renewal.text}. Open the renewal card.` : undefined}
          sub={
            renewal ? (
              // Renewals round: the package tile speaks for the renewal, and a
              // tap opens the Renewal card (both clocks, conversations).
              <span className={cn("inline-flex items-center gap-1.5 min-w-0 max-w-full text-[11px] font-bold", RENEWAL_TONE[renewal.tone])}>
                {renewal.attention && <span className="w-1.5 h-1.5 rounded-full bg-current shrink-0" aria-hidden="true" />}
                <span className="truncate">{renewal.text}</span>
              </span>
            ) : pkg.source === "none" ? undefined : (
              <span
                className={cn(
                  "inline-flex items-center gap-1.5 rounded px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider min-w-0 max-w-full",
                  pkg.fromMindbody
                    ? "bg-[#0a548b]/10 text-[#0a548b] dark:bg-[#5198d8]/15 dark:text-[#8cc4f2]"
                    : "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300",
                )}
                title={pkg.fromMindbody ? "Synced from Mindbody" : "Entered in this app"}
              >
                {pkg.fromMindbody && <span className="w-1.5 h-1.5 rounded-full bg-current opacity-80 shrink-0" aria-hidden="true" />}
                {/* Count first: when the tile is narrow the package NAME is what truncates. */}
                <span className="truncate">{[remaining, pkg.label].filter(Boolean).join(" · ")}</span>
              </span>
            )
          }
        >
          <span className="text-2xl font-black leading-none text-[#F06C22] tabular-nums">{completedCount}</span>
        </Stat>
      </div>

      {/* Its own row under the tiles. It used to sit in `[grid-area:strip]`
          - the same named area as the tile row - so the grid drew the two on
          top of each other and the list covered the tiles. `col-span-full`
          with no named area lands it in a fresh implicit row, in normal
          flow, pushing everything below it down. */}
      {showTrainers && trainerRows.length > 0 && (
        <div className="col-span-full rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 px-3 py-2" role="region" aria-label="Trainers who have trained this client">
          <div className="flex items-center justify-between mb-1">
            <span className="text-[10px] font-bold uppercase tracking-[0.14em] text-muted-foreground">Trained by</span>
            <button type="button" className="text-[11px] font-bold text-muted-foreground min-h-8 px-2" onClick={() => setShowTrainers(false)}>
              Close
            </button>
          </div>
          <ul className="divide-y divide-slate-100 dark:divide-slate-800">
            {trainerRows.map((t) => (
              <li key={t.key} className="flex items-center gap-3 py-1.5">
                <span className="flex-1 min-w-0 truncate text-[13px] font-semibold text-slate-800 dark:text-slate-100">{t.name}</span>
                <span className="w-24 h-1.5 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
                  <span className="block h-full bg-[#F06C22]" style={{ width: `${Math.round(t.share * 100)}%` }} />
                </span>
                <span className="shrink-0 whitespace-nowrap text-right text-[12px] tabular-nums text-slate-600 dark:text-slate-300">
                  {t.sessions} session{t.sessions === 1 ? "" : "s"} · {Math.round(t.share * 100)}%
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </header>
  );
}
