import React, { useState, useMemo } from "react";
import { directoryPackageRead } from "../lib/directory-row";
import { studioTodayKey } from "../lib/studio-time";
import {
  Search,
  User2,
  Plus,
  MapPin,
  Loader2,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useActiveStudio } from "../ActiveStudioContext";
import { Client, Trainer } from "../types";
import { db } from "../firebase";
import { queryStudioIds } from "../lib/tenancy";
import { collection, query, where, getDocs, limit } from "firebase/firestore";
import SyncStatusBadge from "./mindbody/SyncStatusBadge";
import { KaizenToggle } from "../features/trainer-profile/KaizenToggle";
import { studioDateKey } from "../lib/studio-time";

interface Props {
  clients: Client[];
  onSelectClient: (clientId: string) => void;
  onStartOpenSession?: () => void;
  authTrainer?: Trainer | null;
  /**
   * Client ids on the signed-in trainer's Kaizen Roster.
   *
   * Passed in rather than read here: `authTrainer` is captured at sign-in and
   * never re-read, so a roster edit made this session would not show up. The
   * caller derives this from the live `trainers` snapshot.
   */
  kaizenClientIds?: Set<string>;
  /**
   * The signed-in trainer's LIVE document, for the roster toggle on each row.
   *
   * Separate from `authTrainer` above and NOT interchangeable with it:
   * useKaizenRoster rewrites the whole kaizenRoster array, so toggling from
   * the sign-in-time snapshot would drop every entry added since sign-in.
   * Absent means the rows render read-only marks, as before.
   */
  liveAuthTrainer?: Trainer | null;
  onUpdateSessions?: (
    clientId: string,
    current: number,
    delta: number,
  ) => Promise<void>;
  onStartNewClientOnboarding?: (name: string) => void;
}

/** Rows shown with an empty search box. */
const RECENT_LIMIT = 40;

const DIRECTORY_COLUMNS = [
  "Client",
  "Membership",
  "Sessions Remaining",
  "Last Session",
  "Next Session",
] as const;

/** Shared so the skeleton and the real table cannot drift out of alignment. */
function DirectoryTableHead() {
  return (
    <thead>
      <tr className="border-b border-border bg-muted/40">
        {DIRECTORY_COLUMNS.map((label) => (
          <th
            key={label}
            className="py-4 px-6 text-[10px] font-black text-muted-foreground uppercase tracking-widest whitespace-nowrap"
          >
            {label}
          </th>
        ))}
      </tr>
    </thead>
  );
}

/**
 * Placeholder rows shown while the directory query is in flight.
 *
 * Mirrors the real row layout — avatar circle, two-line name block, one bar per
 * remaining column — so the table does not jump when the data lands. Without it
 * the empty "no clients found" message appeared during every load, which reads
 * as "this studio has no clients".
 */
function DirectorySkeleton({ rows = 8 }: { rows?: number }) {
  const bar = "h-3 rounded bg-muted animate-pulse";
  return (
    <div className="w-full overflow-x-auto" aria-busy="true" aria-live="polite">
      <span className="sr-only">Loading clients…</span>
      <table className="w-full text-left border-collapse">
        <DirectoryTableHead />
        <tbody className="divide-y divide-border">
          {Array.from({ length: rows }).map((_, i) => (
            <tr key={i}>
              <td className="py-4 px-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-muted border border-border shrink-0 animate-pulse" />
                  <div className="flex flex-col gap-1.5">
                    <div className={cn(bar, "w-32")} />
                    <div className={cn(bar, "w-20 opacity-60")} />
                  </div>
                </div>
              </td>
              <td className="py-4 px-6">
                <div className={cn(bar, "w-20")} />
              </td>
              <td className="py-4 px-6">
                <div className={cn(bar, "w-8")} />
              </td>
              <td className="py-4 px-6">
                <div className={cn(bar, "w-24")} />
              </td>
              <td className="py-4 px-6">
                <div className={cn(bar, "w-24")} />
              </td>
              <td className="py-4 px-6">
                <div className={cn(bar, "w-6 ml-auto")} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function ClientDirectoryView({
  clients,
  onSelectClient,
  onStartOpenSession,
  authTrainer,
  kaizenClientIds,
  liveAuthTrainer,
  onUpdateSessions,
  onStartNewClientOnboarding,
}: Props) {
  const { availableStudios, activeStudioId } = useActiveStudio();
  const [searchTerm, setSearchTerm] = useState("");
  const [isGlobalSearch, setIsGlobalSearch] = useState(false);
  const [rosterOnly, setRosterOnly] = useState(false);
  const [dbSearchResults, setDbSearchResults] = useState<Client[]>([]);
  const [isSearchingDb, setIsSearchingDb] = useState(false);


  React.useEffect(() => {
    if (!searchTerm.trim()) {
      setIsSearchingDb(true);
      const fetchRecentClients = async () => {
        try {
          const clientsRef = collection(db, "clients");
          /*
           * SCOPED BY STUDIO (tenancy pass, Sep 2026).
           *
           * The `else` branch here used to be `query(clientsRef, limit(30))` —
           * no studio constraint — which is what "global search" meant and
           * what made every client in the platform readable from this screen.
           * Global now means every studio THIS trainer may read, which is the
           * only thing it could honestly have meant.
           */
          const studioIds = queryStudioIds(authTrainer, activeStudioId, {
            includeAll: isGlobalSearch,
          });
          if (studioIds.length === 0) {
            setDbSearchResults([]);
            setIsSearchingDb(false);
            return;
          }
          const q = query(
            clientsRef,
            where("homeStudioId", "in", studioIds),
            limit(30),
          );
          const snap = await getDocs(q);
          const fetched = snap.docs.map(
            (d) => ({ id: d.id, ...(d.data() as any) }) as Client,
          );
          setDbSearchResults(fetched);
        } catch (err) {
          console.error("Error fetching recent clients:", err);
        } finally {
          setIsSearchingDb(false);
        }
      };
      fetchRecentClients();
      return;
    }
    setIsSearchingDb(true);
    const delayDebounceFn = setTimeout(async () => {
      try {
        const term = searchTerm.trim().toLowerCase();
        const alphaOnly = term.replace(/[^a-z]/g, "");
        const prefixLen = alphaOnly.length > 3 ? 3 : alphaOnly.length;
        const prefix = alphaOnly.slice(0, prefixLen);
        const prefixCapitalized =
          prefix.charAt(0).toUpperCase() + prefix.slice(1);

        if (!prefixCapitalized) {
          setDbSearchResults([]);
          setIsSearchingDb(false);
          return;
        }

        /*
         * SCOPED BY STUDIO (tenancy pass, Sep 2026).
         *
         * `clients` used to be `allow read: if isAuthenticated()`, and this
         * query used to run with no studio constraint at all — which is how a
         * trainer at one location could search every client in the platform.
         * The rule is now per-document, and Firestore rejects a whole query
         * that could return a document failing it, so the studios have to be
         * named here. See src/lib/tenancy.ts.
         */
        const studioIds = queryStudioIds(authTrainer, activeStudioId, {
          includeAll: isGlobalSearch,
        });
        if (studioIds.length === 0) {
          setDbSearchResults([]);
          setIsSearchingDb(false);
          return;
        }

        const clientsRef = collection(db, "clients");
        const q1 = query(
          clientsRef,
          where("homeStudioId", "in", studioIds),
          where("firstName", ">=", prefixCapitalized),
          where("firstName", "<=", prefixCapitalized + "\uf8ff"),
          limit(30),
        );
        const q2 = query(
          clientsRef,
          where("homeStudioId", "in", studioIds),
          where("lastName", ">=", prefixCapitalized),
          where("lastName", "<=", prefixCapitalized + "\uf8ff"),
          limit(30),
        );

        const [snap1, snap2] = await Promise.all([getDocs(q1), getDocs(q2)]);
        const uniqueDocs = new Map<string, any>();
        [...snap1.docs, ...snap2.docs].forEach((d) => {
          uniqueDocs.set(d.id, { id: d.id, ...d.data() });
        });

        const candidates = Array.from(uniqueDocs.values());
        const fetched = candidates.filter((c) => {
          const first = (c.firstName || "").toLowerCase();
          const last = (c.lastName || "").toLowerCase();
          const full = `${first} ${last}`;
          const mb = (c.mindbody_name || "").toLowerCase();

          return (
            first.includes(term) ||
            last.includes(term) ||
            full.includes(term) ||
            mb.includes(term) ||
            term.includes(first) ||
            term.includes(last)
          );
        });

        setDbSearchResults(fetched);
      } catch (err) {
        console.error(err);
      } finally {
        setIsSearchingDb(false);
      }
    }, 300);
    return () => clearTimeout(delayDebounceFn);
  }, [searchTerm, isGlobalSearch, activeStudioId]);

  const [clientLastSessionMap, setClientLastSessionMap] = useState<
    Record<string, string>
  >({});

  const today = studioTodayKey();
  const displayClients = useMemo(() => {
    // 1. Studio filtering
    const allowedStudioIds = [
      authTrainer?.primaryHomeStudioId,
      ...(authTrainer?.accessibleStudioIds || []),
    ].filter(Boolean) as string[];

    if (activeStudioId && !allowedStudioIds.includes(activeStudioId)) {
      allowedStudioIds.push(activeStudioId);
    }

    let filtered = Array.from(
      new Map([...clients, ...dbSearchResults].map((c) => [c.id, c])).values(),
    );

    // Filter out dummy/mock clients that do not have a valid first or last name (like test-client-999)
    filtered = filtered.filter((c) => c.firstName || c.lastName);

    // Apply Cross-Studio or Home Studio Territory Filtering if isGlobalSearch is turned off
    if (!isGlobalSearch && allowedStudioIds.length > 0) {
      filtered = filtered.filter(
        (c) => !c.homeStudioId || allowedStudioIds.includes(c.homeStudioId),
      );
    }

    // 1b. Kaizen Roster. Applied before search so "roster only" plus a name
    // search narrows within the roster rather than escaping it.
    if (rosterOnly && kaizenClientIds) {
      filtered = filtered.filter((c) => c.id && kaizenClientIds.has(c.id));
    }

    // 2. Search filtering
    if (searchTerm.trim()) {
      const terms = searchTerm.trim().toLowerCase().split(/\s+/);
      filtered = filtered.filter((c) => {
        const full =
          `${c.firstName || ""} ${c.lastName || ""} ${c.mindbody_name || ""}`.toLowerCase();
        return terms.every((term) => full.includes(term));
      });
    }

    // Sort by recent by default
    const sorted = filtered.sort((a, b) => {
      const aTime = a.createdAt?.toMillis
        ? a.createdAt.toMillis()
        : a.createdAt
          ? new Date(a.createdAt).getTime()
          : 0;
      const bTime = b.createdAt?.toMillis
        ? b.createdAt.toMillis()
        : b.createdAt
          ? new Date(b.createdAt).getTime()
          : 0;
      return bTime - aTime;
    });
    /* No search, no roster filter: show the recent few, not the whole
       studio. Every row was rendered before — 300 rows on a 300-client
       studio — and the audit called it out. The count line under the
       search box says how many more a search reaches. */
    return searchTerm.trim() || rosterOnly ? sorted : sorted.slice(0, RECENT_LIMIT);
  }, [
    clients,
    searchTerm,
    isGlobalSearch,
    rosterOnly,
    kaizenClientIds,
    activeStudioId,
    authTrainer,
    dbSearchResults,
  ]);

  React.useEffect(() => {
    const clientsMissingDate = displayClients.filter(
      (c) => c.id && !c.lastSessionDate && !clientLastSessionMap[c.id],
    );
    if (clientsMissingDate.length === 0) return;

    const idsToFetch = clientsMissingDate.slice(0, 30).map((c) => c.id!);

    const fetchLastSessions = async () => {
      try {
        /*
         * Scoped to this studio (tenancy pass, Sep 2026).
         *
         * Without it the rule would have to resolve up to thirty different
         * client documents to authorise one query, and Firestore allows ten
         * document reads per evaluation — so the query would fail outright.
         * With it the studio branch of the rule matches first and the whole
         * query costs one cached read.
         *
         * The column therefore shows the last session AT THIS STUDIO, which
         * is also the more useful reading of "Last Session" on a directory
         * that is already scoped to one location.
         */
        if (!activeStudioId) return;
        const q = query(
          collection(db, "sessions"),
          where("hostedAtStudioId", "==", activeStudioId),
          where("clientId", "in", idsToFetch),
          limit(100),
        );
        const snap = await getDocs(q);
        const map: Record<string, string> = {};
        snap.docs.forEach((d) => {
          const s = d.data();
          if (s.clientId && s.date) {
            if (!map[s.clientId] || s.date > map[s.clientId]) {
              map[s.clientId] = s.date;
            }
          }
        });
        if (Object.keys(map).length > 0) {
          setClientLastSessionMap((prev) => ({ ...prev, ...map }));
        }
      } catch (err) {
        console.error("Could not fetch last sessions for clients:", err);
      }
    };
    fetchLastSessions();
  }, [displayClients, clientLastSessionMap]);


  return (
    <div className="h-full bg-background p-6 lg:p-10 flex flex-col pt-12 transition-colors duration-200 overflow-hidden">
      <div className="max-w-7xl mx-auto w-full mb-6 shrink-0 flex items-center justify-between">
        <h1 className="text-3xl font-black text-foreground uppercase tracking-tight flex items-center gap-3">
          <User2 className="w-8 h-8 text-primary" />
          Client Directory
          <div className="ml-4 mb-1">
            <SyncStatusBadge />
          </div>
        </h1>
      </div>

      <div className="max-w-7xl mx-auto w-full mb-8 shrink-0">
        <div className="flex flex-col sm:flex-row items-center gap-4">
          <div className="relative group flex-1">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
              {isSearchingDb ? (
                <Loader2 className="h-5 w-5 animate-spin text-primary" />
              ) : (
                <Search className="h-5 w-5 text-muted-foreground group-focus-within:text-primary transition-colors" />
              )}
            </div>
            <Input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search clients..."
              className="w-full bg-card border border-border text-card-foreground placeholder:text-muted-foreground h-12 pl-12 rounded-xl text-base font-medium focus-visible:ring-2 focus-visible:ring-primary/20 focus-visible:border-primary shadow-sm transition-all"
            />
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            {/* The open-session path (no client yet) used to hide in a
                per-row menu; it is a header action now, next to Add Client. */}
            {onStartOpenSession && (
              <Button
                variant="outline"
                onClick={() => onStartOpenSession()}
                className="font-bold uppercase tracking-widest rounded-xl h-12 px-5 cursor-pointer"
                title="Start a session now and assign the client at the end"
              >
                Open session
              </Button>
            )}
            {onStartNewClientOnboarding && (
              <Button
                onClick={() => onStartNewClientOnboarding("")}
                className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold uppercase tracking-widest rounded-xl h-12 px-6 transition-all shadow-sm cursor-pointer"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Client
              </Button>
            )}
          </div>
        </div>

        {!searchTerm.trim() && !rosterOnly && (
          <p className="mt-3 px-2 text-xs font-medium text-muted-foreground">
            Showing the {Math.min(RECENT_LIMIT, displayClients.length)} most recent — type a name to search all clients.
          </p>
        )}

        {activeStudioId && (
          <div className="flex items-center gap-3 mt-4 px-2">
            <button
              onClick={() => setIsGlobalSearch(!isGlobalSearch)}
              className={`w-10 h-5 rounded-full transition-colors relative ${isGlobalSearch ? "bg-primary" : "bg-muted border border-border"}`}
            >
              <div
                className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.5 transition-transform ${isGlobalSearch ? "left-5.5" : "left-0.75"}`}
              />
            </button>
            <span className="text-xs font-bold text-muted-foreground tracking-widest uppercase">
              Search Entire Corporate Network
            </span>
          </div>
        )}

        {kaizenClientIds && kaizenClientIds.size > 0 && (
          <div className="flex items-center gap-3 mt-3 px-2">
            <button
              onClick={() => setRosterOnly(!rosterOnly)}
              aria-pressed={rosterOnly}
              className={`w-10 h-5 rounded-full transition-colors relative ${rosterOnly ? "bg-[#0a548b] dark:bg-[#4a9fd8]" : "bg-muted border border-border"}`}
            >
              <div
                className={`w-3.5 h-3.5 rounded-full bg-white absolute top-0.5 transition-transform ${rosterOnly ? "left-5.5" : "left-0.75"}`}
              />
            </button>
            <span className="text-xs font-bold text-muted-foreground tracking-widest uppercase">
              My Kaizen Roster ({kaizenClientIds.size})
            </span>
          </div>
        )}
      </div>

      <div className="max-w-7xl mx-auto w-full flex-1 overflow-y-auto custom-scrollbar pr-2 pb-24 bg-card rounded-2xl border border-border shadow-sm">
        {isSearchingDb && displayClients.length === 0 ? (
          // Only when there is nothing to show yet — during a re-search the
          // existing rows stay put rather than flashing to skeletons.
          <DirectorySkeleton />
        ) : displayClients.length > 0 ? (
          <div className="w-full overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <DirectoryTableHead />
              <tbody className="divide-y divide-border">
                {displayClients.map((client) => {
                  const isCrossTrainer =
                    activeStudioId &&
                    client.homeStudioId &&
                    client.homeStudioId !== activeStudioId;
                  const originalStudioName =
                    availableStudios?.find((s) => s.id === client.homeStudioId)
                      ?.name || "HQ Network";
                  const pkg = directoryPackageRead(client, today);

                  return (
                    <tr
                      key={client.id}
                      className="group hover:bg-muted/30 transition-colors cursor-pointer"
                      onClick={() => onSelectClient(client.id!)}
                    >
                      <td className="py-4 px-6">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-muted border border-border flex items-center justify-center shrink-0 shadow-sm group-hover:border-primary transition-colors">
                            <span className="text-foreground font-black text-sm tracking-widest uppercase">
                              {client.firstName?.[0]}
                              {client.lastName?.[0]}
                            </span>
                          </div>
                          <div className="flex flex-col">
                            <span className="text-sm font-bold text-foreground group-hover:text-primary transition-colors flex items-center gap-1.5">
                              {client.firstName} {client.lastName}
                              {/* Kaizen Roster mark. Slate, never crimson --
                                  the red kaizen mark means "this rep needs
                                  work" in the session grid, and a client row
                                  must never blur the two. */}
{/* When we have the live trainer document this is a TOGGLE, not
                                  just a mark: flagging someone you are looking at was
                                  previously only possible from your own profile screen,
                                  which is why the roster felt unusable. Falls back to the
                                  read-only mark when no live trainer was passed. */}
                              {client.id && liveAuthTrainer ? (
                                <span
                                  // The row itself opens the client. Without this the
                                  // toggle's click would also navigate away, and the
                                  // reason dialog would unmount as it opened.
                                  onClick={(e) => e.stopPropagation()}
                                  className="shrink-0"
                                >
                                  <KaizenToggle
                                    trainer={liveAuthTrainer}
                                    client={client}
                                    variant="icon"
                                    className="h-8 w-8 border-none bg-transparent"
                                  />
                                </span>
                              ) : (
                                client.id &&
                                kaizenClientIds?.has(client.id) && (
                                  <svg
                                    width="13"
                                    height="13"
                                    viewBox="0 0 16 16"
                                    fill="none"
                                    stroke="currentColor"
                                    strokeWidth={2.2}
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    className="text-[#5b6770] dark:text-[#8b98a4] shrink-0"
                                    role="img"
                                    aria-label="On your Kaizen Roster"
                                  >
                                    <polyline points="2,10 6,6 10,10" opacity={0.55} />
                                    <polyline points="6,13 10,9 14,13" />
                                  </svg>
                                )
                              )}
                            </span>
                            {isCrossTrainer ? (
                              <span className="text-[10px] font-bold text-primary uppercase tracking-widest flex items-center gap-1 mt-0.5">
                                <MapPin className="w-3 h-3" />
                                Visiting: {originalStudioName}
                              </span>
                            ) : (
                              <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest flex items-center gap-1 mt-0.5">
                                <MapPin className="w-3 h-3" />
                                {originalStudioName}
                              </span>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="py-4 px-6 align-middle">
                        <span className={`text-sm font-medium ${pkg.membershipKnown ? "text-foreground" : "text-muted-foreground"}`}>
                          {pkg.membership}
                        </span>
                      </td>
                      <td className="py-4 px-6 align-middle">
                        <span
                          className={`text-sm font-medium ${
                            pkg.sessionsLeftTone === "low"
                              ? "text-amber-600 dark:text-amber-400"
                              : pkg.sessionsLeftTone === "unknown"
                                ? "text-muted-foreground"
                                : "text-foreground"
                          }`}
                        >
                          {pkg.sessionsLeft}
                        </span>
                      </td>
                      <td className="py-4 px-6 align-middle">
                        <span className="text-sm text-muted-foreground">
                          {(() => {
                            const c = client as any;
                            if (c.lastSessionDate) return c.lastSessionDate;
                            if (c.id && clientLastSessionMap[c.id])
                              return clientLastSessionMap[c.id];
                            if (c.lastWorkoutDate) return c.lastWorkoutDate;
                            if (c.currentMachineMetrics) {
                              const dates = Object.values(c.currentMachineMetrics)
                                .map((m: any) => {
                                  if (!m?.lastPerformedDate) return null;
                                  if (typeof m.lastPerformedDate === "string") return m.lastPerformedDate;
                                  if (m.lastPerformedDate?.toDate) return studioDateKey(m.lastPerformedDate.toDate());
                                  if (m.lastPerformedDate instanceof Date) return studioDateKey(m.lastPerformedDate);
                                  return null;
                                })
                                .filter(Boolean) as string[];
                              if (dates.length > 0) {
                                dates.sort();
                                return dates[dates.length - 1];
                              }
                            }
                            return "N/A";
                          })()}
                        </span>
                      </td>
                      <td className="py-4 px-6 align-middle">
                        {pkg.nextSession ? (
                          <span className="text-sm text-foreground font-medium">
                            {pkg.nextSession}
                          </span>
                        ) : (
                          <Badge
                            variant="outline"
                            className="text-amber-600 dark:text-amber-500 border-amber-500/30 bg-amber-50 dark:bg-amber-500/10 text-[10px] font-bold uppercase tracking-widest px-2 py-0.5"
                          >
                            Unscheduled
                          </Badge>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-48 text-center">
            <Search className="w-8 h-8 text-muted-foreground mb-3 opacity-50" />
            <p className="text-muted-foreground font-medium tracking-tight">
              No clients found matching your search.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
